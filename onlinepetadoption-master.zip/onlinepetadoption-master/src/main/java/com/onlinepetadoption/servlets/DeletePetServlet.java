package com.onlinepetadoption.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.json.JSONObject;

@WebServlet("/DeletePetServlet")
public class DeletePetServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        try {
            String petIdParam = request.getParameter("pet_id");
            if (petIdParam == null || petIdParam.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Pet ID is required");
                out.print(jsonResponse.toString());
                return;
            }

            int petId = Integer.parseInt(petIdParam);

            try (Connection conn = DatabaseConnection.getConnection()) {
                try (PreparedStatement stmt = conn.prepareStatement(
                        "DELETE FROM adoption_requests WHERE pet_id = ?")) {
                    stmt.setInt(1, petId);
                    stmt.executeUpdate();
                }

                try (PreparedStatement stmt = conn.prepareStatement(
                        "DELETE FROM pets_info WHERE pet_id = ?")) {
                    stmt.setInt(1, petId);
                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        jsonResponse.put("success", true);
                        jsonResponse.put("message", "Pet deleted successfully");
                    } else {
                        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        jsonResponse.put("success", false);
                        jsonResponse.put("message", "Pet not found");
                    }
                }
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Invalid Pet ID format");
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Database error: " + e.getMessage());
        } finally {
            out.print(jsonResponse.toString());
            out.close();
        }
    }
}