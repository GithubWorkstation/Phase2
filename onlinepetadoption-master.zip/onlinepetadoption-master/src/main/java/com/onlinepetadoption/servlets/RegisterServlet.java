package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.Adopter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

//@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Adopter adopter = new Adopter();
        adopter.setName(request.getParameter("name"));
        adopter.setEmail(request.getParameter("email"));
        adopter.setContact(request.getParameter("contact"));
        adopter.setPassword(request.getParameter("password"));

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO adopters (name, email, contact, password) VALUES (?, ?, ?, ?)")) {

            pstmt.setString(1, adopter.getName());
            pstmt.setString(2, adopter.getEmail());
            pstmt.setString(3, adopter.getContact());
            pstmt.setString(4, adopter.getPassword());

            int rows = pstmt.executeUpdate();

            if (rows > 0) {
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<script>alert('Registered successfully!!'); window.location='registration.jsp';</script>");
            } else {
                throw new Exception("Registration failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('Registration failed. Please try again.'); window.location='registration.jsp';</script>");
        }
    }
}