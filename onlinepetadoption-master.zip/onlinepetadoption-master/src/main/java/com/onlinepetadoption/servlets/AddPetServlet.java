package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.Pet;
import java.io.*;
import java.net.URLEncoder;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;

@WebServlet("/AddPetServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,
        maxFileSize = 1024 * 1024 * 10,
        maxRequestSize = 1024 * 1024 * 50)
public class AddPetServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Pet pet = new Pet();
        pet.setName(request.getParameter("pet-name"));
        pet.setType(request.getParameter("pet-type"));
        pet.setAge(Integer.parseInt(request.getParameter("pet-age")));
        pet.setGender(request.getParameter("pet-gender"));
        pet.setHealthStatus(request.getParameter("health-status"));

        Part imagePart = request.getPart("pet-picture");
        InputStream imageInputStream = imagePart.getInputStream();
        byte[] imageBytes = imageInputStream.readAllBytes();
        pet.setImage(imageBytes);

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();

            String sql = "INSERT INTO pets_info (name, type, age, gender, health_status, adoption_status, image) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, pet.getName());
            pstmt.setString(2, pet.getType());
            pstmt.setInt(3, pet.getAge());
            pstmt.setString(4, pet.getGender());
            pstmt.setString(5, pet.getHealthStatus());
            pstmt.setString(6, request.getParameter("adoption-status"));
            pstmt.setBlob(7, new ByteArrayInputStream(pet.getImage()));

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                response.sendRedirect("add_pets.jsp?success=true");
            } else {
                response.sendRedirect("add_pets.jsp?error=Database+insert+failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_pets.jsp?error=" + URLEncoder.encode(e.getMessage(), "UTF-8"));
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}