package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.Adopter;
import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT * FROM adopters WHERE email = ? AND password = ?")) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Adopter adopter = new Adopter();
                    adopter.setId(rs.getInt("id"));
                    adopter.setName(rs.getString("name"));
                    adopter.setEmail(rs.getString("email"));
                    adopter.setContact(rs.getString("contact"));
                    adopter.setPassword(rs.getString("password"));

                    HttpSession session = request.getSession();
                    session.setAttribute("adopter", adopter);
                    session.setAttribute("adopterId", adopter.getId());
                    session.setAttribute("adopterName", adopter.getName());

                    response.sendRedirect("adopter_loggedin.jsp");
                } else {
                    response.getWriter().println("<script>alert('Invalid email or password'); window.location='adopter_login.jsp';</script>");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<script>alert('Database error: " + e.getMessage() + "'); window.location='adopter_login.jsp';</script>");
        }
    }
}