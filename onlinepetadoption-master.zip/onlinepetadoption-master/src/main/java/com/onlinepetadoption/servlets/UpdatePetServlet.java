package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.Pet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/UpdatePetServlet")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 1,
        maxFileSize = 1024 * 1024 * 10,
        maxRequestSize = 1024 * 1024 * 100
)
public class UpdatePetServlet extends HttpServlet {

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load MySQL JDBC driver", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Pet pet = new Pet();
        pet.setId(Integer.parseInt(request.getParameter("pet_id")));
        pet.setName(request.getParameter("name"));
        pet.setType(request.getParameter("type"));
        pet.setAge(Integer.parseInt(request.getParameter("age")));
        pet.setGender(request.getParameter("gender"));
        pet.setHealthStatus(request.getParameter("health_status"));

        Part imagePart = request.getPart("image");

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql;
            int rowsUpdated;

            if (imagePart != null && imagePart.getSize() > 0) {
                sql = "UPDATE pets_info SET name=?, type=?, age=?, gender=?, health_status=?, adoption_status=?, image=? WHERE pet_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, pet.getName());
                    stmt.setString(2, pet.getType());
                    stmt.setInt(3, pet.getAge());
                    stmt.setString(4, pet.getGender());
                    stmt.setString(5, pet.getHealthStatus());
                    stmt.setString(6, request.getParameter("adoption_status"));
                    stmt.setBlob(7, imagePart.getInputStream());
                    stmt.setInt(8, pet.getId());
                    rowsUpdated = stmt.executeUpdate();
                }
            } else {
                sql = "UPDATE pets_info SET name=?, type=?, age=?, gender=?, health_status=?, adoption_status=? WHERE pet_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, pet.getName());
                    stmt.setString(2, pet.getType());
                    stmt.setInt(3, pet.getAge());
                    stmt.setString(4, pet.getGender());
                    stmt.setString(5, pet.getHealthStatus());
                    stmt.setString(6, request.getParameter("adoption_status"));
                    stmt.setInt(7, pet.getId());
                    rowsUpdated = stmt.executeUpdate();
                }
            }

            if (rowsUpdated > 0) {
                response.sendRedirect("all_pets.jsp");
                return;
            } else {
                request.setAttribute("errorMessage", "No pet found with ID: " + pet.getId());
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("editpet.jsp").forward(request, response);
    }
}