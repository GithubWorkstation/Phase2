package com.onlinepetadoption.servlets;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONObject;

@WebServlet("/GetAdoptionRequestServlet")
public class GetAdoptionRequestServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int requestId = Integer.parseInt(request.getParameter("request_id"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT r.*, p.name as pet_name, p.type as pet_type, p.image_path, " +
                    "a.name as adopter_name, a.email as adopter_email, " +
                    "a.contact as adopter_contact, a.address as adopter_address " +
                    "FROM adoption_requests r " +
                    "JOIN pets_info p ON r.pet_id = p.pet_id " +
                    "JOIN adopters a ON r.adopter_id = a.id " +
                    "WHERE r.request_id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, requestId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    JSONObject json = new JSONObject();
                    json.put("request_id", rs.getInt("request_id"));
                    json.put("pet_id", rs.getInt("pet_id"));
                    json.put("pet_name", rs.getString("pet_name"));
                    json.put("pet_type", rs.getString("pet_type"));
                    json.put("image_path", rs.getString("image_path"));
                    json.put("adopter_id", rs.getInt("adopter_id"));
                    json.put("adopter_name", rs.getString("adopter_name"));
                    json.put("adopter_email", rs.getString("adopter_email"));
                    json.put("adopter_contact", rs.getString("adopter_contact"));
                    json.put("adopter_address", rs.getString("adopter_address"));
                    json.put("request_date", rs.getTimestamp("request_date").toString());
                    json.put("status", rs.getString("status"));
                    json.put("experience", rs.getString("experience"));
                    json.put("notes", rs.getString("notes"));

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json.toString());
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Request not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }
}