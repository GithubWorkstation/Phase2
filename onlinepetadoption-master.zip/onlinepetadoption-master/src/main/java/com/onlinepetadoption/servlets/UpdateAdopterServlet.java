package com.onlinepetadoption.servlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateAdopterServlet")
public class UpdateAdopterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        System.out.println("Received ID: " + idParam);

        if (idParam == null || idParam.trim().isEmpty()) {
            response.getWriter().println("Error: Adopter ID is missing.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idParam.trim());
        } catch (NumberFormatException e) {
            response.getWriter().println("Error: Invalid adopter ID format. Must be a number.");
            return;
        }

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement pstmt = null;
        PreparedStatement checkStmt = null;

        try {
            conn = DatabaseConnection.getConnection();

            checkStmt = conn.prepareStatement("SELECT id FROM adopters WHERE id = ?");
            checkStmt.setInt(1, id);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                response.getWriter().println("Error: No adopter found with ID " + id);
                return;
            }
            if (rs != null) rs.close();

            String sql;
            if (password != null && !password.isEmpty()) {
                sql = "UPDATE adopters SET name = ?, email = ?, contact = ?, password = ? WHERE id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, contact);
                pstmt.setString(4, password);
                pstmt.setInt(5, id);
            } else {
                sql = "UPDATE adopters SET name = ?, email = ?, contact = ? WHERE id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, contact);
                pstmt.setInt(4, id);
            }

            int updatedRows = pstmt.executeUpdate();
            if (updatedRows > 0) {
                response.getWriter().println("Adopter updated successfully.");
            } else {
                response.getWriter().println("Error: Failed to update adopter.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error updating adopter: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (checkStmt != null) checkStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}