package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.Pet;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class PetsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Pet> pets = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM pets_info WHERE adoption_status='Available'")) {

            while (rs.next()) {
                Pet pet = new Pet();
                pet.setId(rs.getInt("pet_id"));
                pet.setName(rs.getString("name"));
                pet.setType(rs.getString("type"));
                pet.setAge(rs.getInt("age"));
                pet.setGender(rs.getString("gender"));
                pet.setHealthStatus(rs.getString("health_status"));

                Blob imageBlob = rs.getBlob("image");
                if (imageBlob != null) {
                    pet.setImage(imageBlob.getBytes(1, (int) imageBlob.length()));
                }

                pets.add(pet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Database error", e);
        }

        request.setAttribute("pets", pets);
        request.getRequestDispatcher("pets.jsp").forward(request, response);
    }
}