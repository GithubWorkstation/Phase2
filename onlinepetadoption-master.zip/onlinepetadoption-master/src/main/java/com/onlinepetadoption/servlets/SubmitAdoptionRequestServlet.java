package com.onlinepetadoption.servlets;

import com.onlinepetadoption.models.AdoptionRequest;
import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/SubmitAdoptionRequestServlet")
public class SubmitAdoptionRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        try {
            int petId = Integer.parseInt(request.getParameter("pet_id"));
            int adopterId = Integer.parseInt(request.getParameter("adopter_id"));
            String housingType = request.getParameter("housing_type");
            String previousExperience = request.getParameter("previous_experience");

            boolean hasCurrentPets = "yes".equals(request.getParameter("has_current_pets"));
            String currentPetsDetails = hasCurrentPets ? request.getParameter("current_pets_details") : "";

            AdoptionRequest adoptionRequest = new AdoptionRequest();
            adoptionRequest.setPetId(petId);
            adoptionRequest.setAdopterId(adopterId);
            adoptionRequest.setHousingType(housingType);
            adoptionRequest.setPreviousPetsExperience(previousExperience);
            adoptionRequest.setHasCurrentPets(hasCurrentPets);
            adoptionRequest.setCurrentPetsDetails(currentPetsDetails);

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO adoption_requests (pet_id, adopter_id, housing_type, " +
                        "previous_pets_experience, has_current_pets, current_pets_details, status) " +
                        "VALUES (?, ?, ?, ?, ?, ?, 'Pending')";

                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, adoptionRequest.getPetId());
                    pstmt.setInt(2, adoptionRequest.getAdopterId());
                    pstmt.setString(3, adoptionRequest.getHousingType());
                    pstmt.setString(4, adoptionRequest.getPreviousPetsExperience());
                    pstmt.setBoolean(5, adoptionRequest.isHasCurrentPets());
                    pstmt.setString(6, adoptionRequest.getCurrentPetsDetails());

                    int rowsAffected = pstmt.executeUpdate();

                    if (rowsAffected > 0) {
                        session.setAttribute("requestStatus", "success");
                        session.setAttribute("requestMessage", "Adoption request submitted successfully!");
                    } else {
                        session.setAttribute("requestStatus", "error");
                        session.setAttribute("requestMessage", "Failed to submit adoption request. No rows affected.");
                    }
                }
            }
        } catch (NumberFormatException e) {
            session.setAttribute("requestStatus", "error");
            session.setAttribute("requestMessage", "Invalid ID format: " + e.getMessage());
        } catch (SQLException e) {
            session.setAttribute("requestStatus", "error");
            session.setAttribute("requestMessage", "Database error: " + e.getMessage());
        } catch (Exception e) {
            session.setAttribute("requestStatus", "error");
            session.setAttribute("requestMessage", "Error: " + e.getMessage());
        }

        response.sendRedirect("pets");
    }
}