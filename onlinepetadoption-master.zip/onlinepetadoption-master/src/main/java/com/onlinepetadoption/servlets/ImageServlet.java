package com.onlinepetadoption.servlets;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int petId = Integer.parseInt(request.getParameter("pet_id"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT image_path FROM pets_info WHERE pet_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, petId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String imagePath = rs.getString("image_path");
                    if (imagePath != null && !imagePath.isEmpty()) {
                        File file = new File(imagePath);
                        if (file.exists()) {
                            String mimeType = getServletContext().getMimeType(imagePath);
                            response.setContentType(mimeType != null ? mimeType : "application/octet-stream");

                            try (InputStream in = new FileInputStream(file);
                                 OutputStream out = response.getOutputStream()) {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = in.read(buffer)) != -1) {
                                    out.write(buffer, 0, bytesRead);
                                }
                            }
                            return;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendError(HttpServletResponse.SC_NOT_FOUND);
    }
}