package com.onlinepetadoption.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;

@WebServlet("/ImageAllPetServlet")
public class ImageAllPetServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String petId = request.getParameter("pet_id");
        if (petId == null || petId.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Pet ID is required");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT image FROM pets_info WHERE pet_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, Integer.parseInt(petId));
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        InputStream imageStream = rs.getBinaryStream("image");
                        if (imageStream != null) {
                            response.setContentType("image/jpeg");
                            OutputStream out = response.getOutputStream();

                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = imageStream.read(buffer)) != -1) {
                                out.write(buffer, 0, bytesRead);
                            }
                            out.flush();
                            return;
                        }
                    }
                }
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        }

        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Image not found");
    }
}