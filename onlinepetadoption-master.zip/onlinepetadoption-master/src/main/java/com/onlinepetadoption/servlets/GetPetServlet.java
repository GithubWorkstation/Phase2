package com.onlinepetadoption.servlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.json.JSONObject;

@WebServlet("/GetPetServlet")
public class GetPetServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        JSONObject jsonResponse = new JSONObject();

        try {
            String petIdParam = request.getParameter("pet_id");
            if (petIdParam == null || petIdParam.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.put("error", "Pet ID is required");
                response.getWriter().write(jsonResponse.toString());
                return;
            }

            int petId = Integer.parseInt(petIdParam);

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM pets_info WHERE pet_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, petId);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        JSONObject pet = new JSONObject();
                        pet.put("pet_id", rs.getInt("pet_id"));
                        pet.put("name", rs.getString("name"));
                        pet.put("type", rs.getString("type"));
                        pet.put("age", rs.getInt("age"));
                        pet.put("gender", rs.getString("gender"));
                        pet.put("health_status", rs.getString("health_status"));
                        pet.put("adoption_status", rs.getString("adoption_status"));

                        response.getWriter().write(pet.toString());
                    } else {
                        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        jsonResponse.put("error", "Pet not found");
                        response.getWriter().write(jsonResponse.toString());
                    }
                }
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("error", "Invalid Pet ID format");
            response.getWriter().write(jsonResponse.toString());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("error", "Server error: " + e.getMessage());
            response.getWriter().write(jsonResponse.toString());
            e.printStackTrace();
        }
    }
}