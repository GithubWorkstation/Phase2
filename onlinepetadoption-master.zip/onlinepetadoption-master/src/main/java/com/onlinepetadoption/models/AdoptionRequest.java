package com.onlinepetadoption.models;

import java.sql.Timestamp;

public class AdoptionRequest {
    private int requestId;
    private int petId;
    private String petName;
    private String petType;
    private int adopterId;
    private String adopterName;
    private String adopterEmail;
    private String adopterContact;
    private Timestamp requestDate;
    private String status;
    private String housingType;
    private String previousPetsExperience;
    private boolean hasCurrentPets;
    private String currentPetsDetails;

    // Getters and setters for all fields
    public int getRequestId() { return requestId; }
    public void setRequestId(int requestId) { this.requestId = requestId; }

    public int getPetId() { return petId; }
    public void setPetId(int petId) { this.petId = petId; }

    public String getPetName() { return petName; }
    public void setPetName(String petName) { this.petName = petName; }

    public String getPetType() { return petType; }
    public void setPetType(String petType) { this.petType = petType; }

    public int getAdopterId() { return adopterId; }
    public void setAdopterId(int adopterId) { this.adopterId = adopterId; }

    public String getAdopterName() { return adopterName; }
    public void setAdopterName(String adopterName) { this.adopterName = adopterName; }

    public String getAdopterEmail() { return adopterEmail; }
    public void setAdopterEmail(String adopterEmail) { this.adopterEmail = adopterEmail; }

    public String getAdopterContact() { return adopterContact; }
    public void setAdopterContact(String adopterContact) { this.adopterContact = adopterContact; }

    public Timestamp getRequestDate() { return requestDate; }
    public void setRequestDate(Timestamp requestDate) { this.requestDate = requestDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getHousingType() { return housingType; }
    public void setHousingType(String housingType) { this.housingType = housingType; }

    public String getPreviousPetsExperience() { return previousPetsExperience; }
    public void setPreviousPetsExperience(String previousPetsExperience) {
        this.previousPetsExperience = previousPetsExperience;
    }

    public boolean isHasCurrentPets() { return hasCurrentPets; }
    public void setHasCurrentPets(boolean hasCurrentPets) { this.hasCurrentPets = hasCurrentPets; }

    public String getCurrentPetsDetails() { return currentPetsDetails; }
    public void setCurrentPetsDetails(String currentPetsDetails) {
        this.currentPetsDetails = currentPetsDetails;
    }
}