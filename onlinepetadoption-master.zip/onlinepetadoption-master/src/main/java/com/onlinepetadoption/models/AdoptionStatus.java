package com.onlinepetadoption.models;

public enum AdoptionStatus {
    AVAILABLE("Available"),
    PENDING("Pending"),
    ADOPTED("Adopted");

    private final String value;

    AdoptionStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static AdoptionStatus fromString(String text) {
        for (AdoptionStatus status : AdoptionStatus.values()) {
            if (status.value.equalsIgnoreCase(text)) {
                return status;
            }
        }
        return null;
    }
}